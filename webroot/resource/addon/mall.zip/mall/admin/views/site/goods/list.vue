<template>
    <div class="main-container">

        <el-card class="box-card !border-none" shadow="never">

            <div class="flex justify-between items-center">
                <span class="text-page-title">{{ pageName }}</span>
                <div>
                    <el-button type="primary" @click="router.push('/mall/goods/import')">{{ t('商品导入') }}</el-button>
                    <el-button type="primary" @click="addEvent">{{ t('addGoods') }}</el-button>
                </div>
            </div>

            <el-card class="box-card !border-none my-[10px] table-search-wrap" shadow="never">
                <el-form :inline="true" label-width="70px" :model="goodsTable.searchParam" ref="searchFormRef" class="page-form">
                    <el-form-item :label="t('goodsName')" prop="goods_name">
                        <el-input v-model.trim="goodsTable.searchParam.goods_name" :placeholder="t('goodsNamePlaceholder')" maxlength="60" clearable class="search-input" />
                    </el-form-item>
                    <el-form-item :label="t('goodsCategory')" prop="goods_category">
                        <el-cascader v-model="goodsTable.searchParam.goods_category" :options="goodsCategoryOptions" :placeholder="t('请选择分类')" clearable :props="{ value: 'value', label: 'label', emitPath:false }" class="search-input"/>
                    </el-form-item>
                    <el-form-item :label="t('goodsType')" prop="goods_type">
                        <el-select v-model="goodsTable.searchParam.goods_type" :placeholder="t('goodsTypePlaceholder')" clearable class="search-input">
                            <el-option  label="全部" value="all" />
                            <el-option v-for="item in goodsType" :key="item.type" :label="item.name" :value="item.type" />
                        </el-select>
                    </el-form-item>

                    <el-form-item :label="t('brand')" prop="brand_id">
                        <el-select v-model="goodsTable.searchParam.brand_id" :placeholder="t('brandPlaceholder')" clearable filterable remote reserve-keyword :remote-method="getBrandListFn" class="search-input">
                            <el-option  label="全部" value="all" />
                            <el-option v-for="item in brandOptions" :key="item.brand_id" :label="item.brand_name" :value="item.brand_id" />
                        </el-select>
                    </el-form-item>
                    <el-form-item :label="t('labelIds')" prop="label_ids">
                        <el-select v-model="goodsTable.searchParam.label_ids" :placeholder="t('labelIdsPlaceholder')" clearable class="search-input">
                            <el-option  label="全部" value="all" />
                            <el-option v-for="item in labelOptions" :key="item.label_id" :label="item.label_name" :value="item.label_id" />
                        </el-select>
                    </el-form-item>
                    <el-form-item :label="t('goodsSource')" prop="goods_source">
                        <el-select v-model="goodsTable.searchParam.goods_source" :placeholder="t('goodsSourcePlaceholder')" clearable class="search-input">
                            <el-option  label="全部" value="all" />
                            <el-option v-for="(item,index) in goodsSource" :key="index" :label="item.name" :value="index" />
                        </el-select>
                    </el-form-item>
                    <el-form-item :label="t('saleNum')" prop="sale_num">
                        <div class="region-input search-input">
                            <input type="text" :placeholder="t('startSaleNumPlaceholder')" maxlength="10" v-model.trim="goodsTable.searchParam.start_sale_num" @keyup="filterDigit($event)" class="w-[130px]">
                            <span class="separator">-</span>
                            <input type="text" :placeholder="t('endSaleNumPlaceholder')" maxlength="10" v-model.trim="goodsTable.searchParam.end_sale_num" @keyup="filterDigit($event)" class="w-[130px]">
                        </div>
                    </el-form-item>
                    <el-form-item :label="t('skuPrice')" prop="sku_price">
                        <div class="region-input search-input">
                            <input type="text" :placeholder="t('startPricePlaceholder')" maxlength="10" v-model.trim="goodsTable.searchParam.start_price" @keyup="filterDigit($event)" class="w-[130px]">
                            <span class="separator">-</span>
                            <input type="text" :placeholder="t('endPricePlaceholder')" maxlength="10" v-model.trim="goodsTable.searchParam.end_price" @keyup="filterDigit($event)" class="w-[130px]">
                        </div>
                    </el-form-item>

                    <el-form-item>
                        <el-button type="primary" @click="loadGoodsList()">{{ t('search') }}</el-button>
                        <el-button @click="resetForm(searchFormRef)">{{ t('reset') }}</el-button>
                        <el-button type="primary" @click="exportEvent">{{ t('export') }}</el-button>
                    </el-form-item>
                </el-form>
            </el-card>

            <div class="mt-[10px]">

                <el-tabs v-model="goodsTable.searchParam.status_type" class="goods-tabs" @tab-click="tabHandleClick">
                    <el-tab-pane :label="t('all')" name=""></el-tab-pane>
                    <template v-for="item in goodsStatus" :key="item.value">
                        <el-tab-pane v-if="item.value != -4" :label="item.label" :name="item.value"></el-tab-pane>
                        <el-tab-pane v-if="item.value == -4" :name="item.value">
                            <template #label>
                                <el-badge :value="item.count" :offset="[8, 2]" :hidden="!Boolean(Number(item.count))"  :max="99" class="item">
                                    <span>{{item.label}}</span>
                                </el-badge>
                            </template>
                        </el-tab-pane>
                    </template>
                </el-tabs>

                <div class="mb-[10px] flex items-center">
                    <el-dropdown class="mr-[20px] !text-primary w-[125px]">
                        <span class="el-dropdown-link">
                            <span>{{ currentSelectMode === 'all' ? t('全选所有页') : t('全选当前页')}}</span>(<span class="text-center inline-block">{{ selectedCount }}</span>)
                            <el-icon>
                                <arrow-down />
                            </el-icon>
                        </span>
                        <template #dropdown>
                            <el-dropdown-menu>
                                <el-dropdown-item class="select-wrap" :class="{ active: currentSelectMode === 'all' }" @click="selectAllPages">
                                    全选所有页
                                </el-dropdown-item>
                                <el-dropdown-item class="select-wrap"  :class="{ active: currentSelectMode === 'page' }" @click="toggleChange">
                                    全选当前页
                                </el-dropdown-item>
                            </el-dropdown-menu>
                        </template>
                    </el-dropdown>
                    <!-- <el-checkbox v-model="toggleCheckbox" size="large" class="px-[14px]" @change="toggleChange" :indeterminate="isIndeterminate" /> -->
                    <el-button @click="batchGoodsStatus(1)" size="small" v-if="goodsTable.searchParam.status_type != '1'">{{ t('batchOnGoods') }}</el-button>
                    <el-button @click="batchGoodsStatus(0)" size="small" v-if="goodsTable.searchParam.status_type != '0'">{{ t('batchOffGoods') }}</el-button>
                    <el-button @click="batchDeleteGoods" size="small">{{ t('batchDeleteGoods') }}</el-button>
                    <el-button @click="batchSetGoods" size="small">{{ t('batchSetting') }}</el-button>
                </div>

                <el-table :data="goodsTable.data" size="large" v-loading="goodsTable.loading" ref="goodsListTableRef" @sort-change="sortChange" :row-key="row => row.goods_id" :default-selection="defaultSelection" @selection-change="handleSelectionChange">
                    <template #empty>
                        <span>{{ !goodsTable.loading ? t('emptyData') : '' }}</span>
                    </template>
                    <el-table-column type="selection" width="55" />

                    <el-table-column prop="goods_id" :label="t('goodsInfo')" min-width="300">
                        <template #default="{ row }">
                            <div class="flex items-center cursor-pointer" @click="previewEvent(row)">
                                <div class="min-w-[90px] h-[90px] flex items-center justify-center">
                                    <el-image v-if="row.goods_cover_thumb_small" class="w-[90px] h-[90px]" :src="img(row.goods_cover_thumb_small)" fit="contain">
                                        <template #error>
                                            <div class="image-slot">
                                                <img class="w-[90px] h-[90px]" src="@/addon/mall/assets/goods_default.png" />
                                            </div>
                                        </template>
                                    </el-image>
                                    <img v-else class="w-[90px] h-[90px]" src="@/addon/mall/assets/goods_default.png" fit="contain" />
                                </div>
                                <div class="ml-2  flex flex-col items-start">
                                    <span :title="row.goods_name" class="multi-hidden">{{ row.goods_name }}</span>
                                    <div v-if="row.supply_id" @click.stop="router.push({path:'/supply/select/supply', query: { site_id: row.supply_id }})">{{ t('supplyName') }}：{{ row.supply_name }}</div>
                                    <span class="text-primary text-[12px]">{{ row.goods_type_name }}</span>
                                    <div class="flex flex-wrap mt-[4px] gap-[4px]">
                                        <el-tooltip v-for="(item, index) in row.active" :key="index" placement="top">
                                            <template #content>
                                                <div style="white-space: pre-wrap">
                                                    {{item.name.trim() || item.short?.active_name }}
                                                </div>
                                            </template>
                                            <span class="text-[12px] text-white rounded-[4px] px-[4px] leading-[18px]"  @click.stop="activeclick(item)" :style="{ backgroundColor: item.short?.bg_color || '#333' }">
                                                {{ item.short?.name }}
                                            </span>
                                        </el-tooltip>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </el-table-column>

                    <el-table-column prop="price" :label="t('skuPrice')" min-width="120" align="right" sortable="custom">
                        <template #default="{ row }">
                            <div class="cursor-pointer price-wrap" @click="editPriceEvent(row)">
                                <span>￥{{ row.goodsSku.price }}</span>
                                <el-icon class="icon-wrap ml-[5px] invisible">
                                    <EditPen />
                                </el-icon>
                            </div>
                        </template>
                    </el-table-column>

                    <el-table-column prop="stock" :label="t('stock')" min-width="120" sortable="custom">
                        <template #default="{ row }">
                            <div class="cursor-pointer stock-wrap" @click="editStockEvent(row)" v-if="!row.supply_id">
                                <span>{{ row.stock }}</span>
                                <el-icon class="icon-wrap ml-[5px] invisible">
                                    <EditPen />
                                </el-icon>
                            </div>
                            <div class="stock-wrap" v-else>
                                <span>{{ row.stock }}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="sale_num" :label="t('saleNum')" min-width="100" sortable="custom" />
                    <el-table-column prop="status" :label="t('status')" min-width="100">
                        <template #default="{ row }">
                            <div v-if="row.status == 1">{{ t('statusOn') }}</div>
                            <div v-if="row.status == 0">{{ t('statusOff') }}</div>
                            <div v-if="row.status == -3">{{ t('waitOffLine') }}</div>
                            <div v-if="row.status == 0 && row.is_supply_update == 1" class="text-primary">货源更新</div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="audit_status_name" :label="t('auditStatus')" min-width="100" >
                        <template #default="{ row }">
                            <div class='text-primary cursor-pointer' v-if="row.audit_status == -1" @click="handleAuditRefuse(row.audit_reason)">{{ row.audit_status_name }}</div>
                            <div v-else>{{ row.audit_status_name }}</div>
                        </template>
                    </el-table-column>
                    <el-table-column prop="sort"  min-width="120" sortable="custom"  class-name="sort-column">
                        <template #header>
                            <span class="mr-[4px]">{{t('sort')}}</span>
                            <el-tooltip class="box-item" effect="dark" :content="t('sortPlaceholder')"  placement="bottom">
                                <el-icon><QuestionFilled /></el-icon>
                            </el-tooltip>
                        </template>
                        <template #default="{ row }">
                            <el-input v-model="row.shop_sort" class="input-width-sort" maxlength="10" @input="sortInputListener($event, row)" />
                        </template>
                    </el-table-column>

                    <el-table-column prop="create_time" :label="t('createTime')" min-width="150" sortable="custom">
                        <template #default="{ row }">
                            <div>{{ row.create_time }}</div>
                        </template>
                    </el-table-column>

                    <el-table-column :label="t('operation')" fixed="right" align="right" min-width="120">
                        <template #default="{ row }">
                            <el-button type="primary" link @click="editEvent(row)">{{ t('edit') }}</el-button>
                            <el-button type="primary" link @click="spreadEvent(row)">{{ t('spreadGoods') }}</el-button>
                            <el-button type="primary" link @click="memberPriceEvent(row)">{{ t('memberPrice') }}</el-button>
                            <el-button type="primary" link @click="vipcardPriceEvent(row)">付费会员价</el-button>
                            <el-button type="primary" v-if="row.status == 1" link @click="statusChange(row, 0)">{{ t('statusActionOff') }}</el-button>
                            <el-button type="primary" v-else-if="row.status == 0" link @click="statusChange(row, 1)">{{ t('statusActionOn') }}</el-button>
                            <el-button type="primary" link @click="copyEvent(row)">{{ t('copyGoods') }}</el-button>
                            <el-button type="primary" link @click="deleteEvent(row.goods_id)">{{ t('delete') }}</el-button>
                            <el-button type="primary" link v-if="row.supply_id" @click="supplyEvent(row)">{{ t('供货详情') }}</el-button>
                        </template>
                    </el-table-column>

                </el-table>
                <div class="mt-[16px] flex justify-end">
                    <!-- <div class="flex items-center flex-1">
                        <el-checkbox v-model="toggleCheckbox" size="large" class="px-[14px]" @change="toggleChange" :indeterminate="isIndeterminate" />
                        <el-button @click="batchGoodsStatus(1)" size="small">{{ t('batchOnGoods') }}</el-button>
                        <el-button @click="batchGoodsStatus(0)" size="small">{{ t('batchOffGoods') }}</el-button>
                        <el-button @click="batchDeleteGoods" size="small">{{ t('batchDeleteGoods') }}</el-button>
                    </div> -->

                    <el-pagination v-model:current-page="goodsTable.page" v-model:page-size="goodsTable.limit"
                        layout="total, sizes, prev, pager, next, jumper" :total="goodsTable.total"
                        @size-change="loadGoodsList()" @current-change="loadGoodsList" />
                </div>

            </div>

        </el-card>

        <!-- 商品库存编辑弹出框 -->
        <goods-stock-edit-popup ref="goodsStockEditPopupRef" @load="loadGoodsList" />

        <!-- 商品价格编辑弹出框 -->
        <goods-price-edit-popup ref="goodsPriceEditPopupRef" @load="loadGoodsList" />

        <!-- 商品推广弹出框 -->
        <spread-popup ref="spreadPopupRef" />

        <!-- 审核未通过弹框 -->
        <el-dialog  v-model="auditRefuseDialog" :title="t('reason')" width="500" >
            <span>{{refuseData}}</span>
            <template #footer>
                <el-button type="primary" @click="auditRefuseDialog = false">{{t('confirm')}}</el-button>
            </template>
        </el-dialog>

        <!-- 会员价弹出框 -->
        <goods-member-price-popup ref="memberPricePopupRef" @load="loadGoodsList" />
        <!-- 付费会员价弹出框 -->
        <vipcard-price-popup ref="vipcardPricePopupRef" @load="loadGoodsList" />
        <!-- 供货详情弹出框 -->
        <supply-detail-popup ref="supplyDetailPopupRef" />

        <!-- 批量设置弹出框 -->
        <goods-batch-settings-popup ref="goodsBatchSettingPopupRef" @load="loadGoodsListReset" />

        <export-sure ref="exportSureDialog" v-model:show="flag" type="shop_goods" isSite="true" :searchParam="goodsTable.searchParam" @close="handleClose" />
    </div>
</template>

<script lang="ts" setup>
import { reactive, ref, nextTick, computed } from 'vue'
import { t } from '@/lang'
import { debounce, img, filterDigit, setTablePageStorage, getTablePageStorage } from '@/utils/common'
import { ElMessage, ElMessageBox, FormInstance } from 'element-plus'
import { useRoute, useRouter } from 'vue-router'
import { cloneDeep } from 'lodash-es'
import goodsMemberPricePopup from '@/addon/mall/views/site/goods/components/goods-member-price-popup.vue'
import vipcardPricePopup from '@/addon/mall/views/site/goods/components/vipcard-price-popup.vue'
import goodsStockEditPopup from '@/addon/mall/views/site/goods/components/goods-stock-edit-popup.vue'
import goodsPriceEditPopup from '@/addon/mall/views/site/goods/components/goods-price-edit-popup.vue'
import goodsSpreadPopup from '@/addon/mall/views/site/goods/components/goods-spread-popup.vue'
import supplyDetailPopup from '@/addon/mall/views/site/goods/components/supply-detail-popup.vue'
import goodsBatchSettingsPopup from '@/addon/mall/views/site/goods/components/goods-batch-settings-popup.vue'
import { getCategoryTree, getBrandList, getLabelList } from '@/app/api/basic_site'
import { getGoodsPageList, getGoodsStatusType, editGoodsSort, editGoodsStatus, copyGoods, deleteGoods, getGoodsType, getGoodsSource } from '@/app/lang/zh-cn/api/site/goods'
import { getMemberLevelAll } from '@/app/api/member'
import { getVipcardAll } from '@/app/api/vip_card'
import spreadPopup from '@/components/spread-popup/index.vue'
import userStore from '@/stores/modules/user'

const user_store = userStore()

const router = useRouter()
const route = useRoute()

const pageName = route.meta.title
const repeat = ref(false)

const goodsTable = reactive({
    page: 1,
    limit: 10,
    total: 0,
    loading: true,
    data: [],
    searchParam: {
        goods_name: '',
        goods_category: [],
        goods_type: '',
        brand_id: '',
        label_ids: '',
        goods_source: '',
        start_sale_num: '',
        end_sale_num: '',
        start_price: '',
        end_price: '',
        status_type: Object.keys(route.query).length ? (route.query.status === '' ? route.query.status : parseInt(route.query.status)) : '',
        order: '',
        sort: ''
    }
})

const searchFormRef = ref<FormInstance>()

// 正则表达式
const regExp = {
    number: /^\d{0,10}$/,
    digit: /^\d{0,10}(.?\d{0,2})$/
}

// 条件筛选查询

// 商品分类
const goodsCategoryOptions: any = reactive([])

// 商品状态
const goodsStatus: any = reactive({})

// 商品类型
const goodsType: any = reactive({})

// 品牌列表下拉框
const brandOptions: any = ref([])

// 标签组列表下拉框
const labelOptions: any = reactive([])

// 商品来源
const goodsSource: any = reactive({})

const getGoodsStatusFn = () => {
    getGoodsStatusType().then((res) => {
        const data = res.data
        if (data) {
            Object.assign(goodsStatus, data)
        }
    })
}

// 初始化数据
const initData = () => {
    // 查询商品分类树结构
    getCategoryTree({
        addon: 'mall'
    }).then((res) => {
        const data = res.data
        if (data) {
            const goodsCategoryTree: any = []
            data.forEach((item: any) => {
                const children: any = []
                if (item.child_list) {
                    item.child_list.forEach((childItem: any) => {
                        children.push({
                            value: childItem.category_id,
                            label: childItem.category_name
                        })
                    })
                }
                goodsCategoryTree.push({
                    value: item.category_id,
                    label: item.category_name,
                    children
                })
            })
            goodsCategoryOptions.splice(0, goodsCategoryOptions.length, ...goodsCategoryTree)
            goodsCategoryOptions.unshift({
                value: '',
                label: '全部',
                children: []
            })
        }
    })

    getGoodsStatusFn()

    // 商品标签
    getLabelList({}).then((res) => {
        const data = res.data
        if (data) {
            labelOptions.push(...data)
        }
    })
    // 商品类型
    getGoodsType().then((res) => {
        const data = res.data
        if (data) {
            Object.assign(goodsType, data)
        }
    })
    // 商品来源
    getGoodsSource().then((res) => {
        const data = res.data
        if (data) {
            Object.assign(goodsSource, data)
        }
    })
}

initData()
// 商品品牌
const getBrandListFn = (query = '') => {
    getBrandList({brand_name: query, addon:'mall'}).then((res) => {
        brandOptions.value = res.data
    })
}

// 当前选中tab页面
const tabHandleClick = (tab: any, event: Event) => {
    goodsTable.searchParam.status_type = tab.props.name
    isReset.value = true
    loadGoodsList()
}

// 全选所有页时排除的 ID
const excludedIds = ref<number[]>([])
// 是否全选所有页
const isSelectAllPages = ref(false)

// 批量复选框
const toggleCheckbox = ref()
const currentSelectMode = ref<'all' | 'page' | null>(null)

// 复选框中间状态
const isIndeterminate = ref(false)

// 全选当前页
const toggleChange = () => {
    restoringSelection.value = true // 加锁
    if (currentSelectMode.value === 'page') {
        isSelectAllPages.value = false
        currentSelectMode.value = null
        excludedIds.value = []
        multipleSelection.value = []
        goodsListTableRef.value.clearSelection()
    } else {
        isSelectAllPages.value = false
        currentSelectMode.value = 'page'
        excludedIds.value = []
        multipleSelection.value = []
        goodsTable.data.forEach(row => {
            goodsListTableRef.value.toggleRowSelection(row, true)
        })
        multipleSelection.value = [...goodsTable.data]
    }
    nextTick(() => {
        restoringSelection.value = false // 解锁
    })
}

// 全选所有页
const selectAllPages = () => {
    restoringSelection.value = true // 加锁
    if (currentSelectMode.value === 'all') {
        isSelectAllPages.value = false
        currentSelectMode.value = null
        excludedIds.value = []
        multipleSelection.value = []
        goodsListTableRef.value.clearSelection()
    } else {
        // goodsListTableRef.value.clearSelection()
        excludedIds.value = []
        multipleSelection.value = []
        isSelectAllPages.value = true
        currentSelectMode.value = 'all'
        goodsTable.data.forEach(row => {
            goodsListTableRef.value.toggleRowSelection(row, true)
        })
    }
    nextTick(() => {
        restoringSelection.value = false // 解锁
    })
}
const defaultSelection = computed(() => {
    if (isSelectAllPages.value) {
        return goodsTable.data.filter(item => !excludedIds.value.includes(item.goods_id))
    } else {
        return multipleSelection.value
    }
})

const goodsListTableRef = ref()

// 选中数据
const multipleSelection: any = ref([])
const restoringSelection = ref(false)

const handleSelectionChange = (val: any[]) => {
    if (restoringSelection.value) return // 阻止自动恢复触发逻辑

    if (isSelectAllPages.value) {
        const currentPageIds = goodsTable.data.map(item => item.goods_id)
        const selectedIds = val.map(item => item.goods_id)
        const unselected = currentPageIds.filter(id => !selectedIds.includes(id))

        excludedIds.value = Array.from(new Set([...excludedIds.value, ...unselected]))
        excludedIds.value = excludedIds.value.filter(id => !selectedIds.includes(id))
    } else {
        multipleSelection.value = val
    }
}
const selectedCount = computed(() => {
    if (isSelectAllPages.value) {
        return goodsTable.total - excludedIds.value.length
    } else {
        return multipleSelection.value.length
    }
})

const getBatchPayload = () => {
    if (isSelectAllPages.value) {
        return {
            is_all: 1,
            ids: excludedIds.value,
            where: {
                ...goodsTable.searchParam
            }
        }
    } else {
        return {
            is_all: 0,
            ids: multipleSelection.value.map(item => item.goods_id),
            where: {
                ...goodsTable.searchParam
            }
        }
    }
}

// 商品预览
const previewEvent = (data: any) => {
    const url = router.resolve({
        path: '/preview/wap',
        query: {
            page: `/addon/mall/pages/goods/detail?goods_id=${data.goods_id}`
        }
    })
    window.open(url.href)
}
const activeclick = (data: any) => {
    if (data.list[0].join_type == 'active_discount') {
        const routeUrl = router.resolve({
            path: '/mall/marketing/discount/detail',
            query: {
                id: data.list[0].join_id
            }
        })
        window.open(routeUrl.href, '_blank')
    }
}

// 监听排序
const sortChange = (event: any) => {
    let sort = ''
    if (event.order == 'ascending') {
        sort = 'asc'
    } else if (event.order == 'descending') {
        sort = 'desc'
    }
    if (sort) {
        goodsTable.searchParam.order = event.prop
        goodsTable.searchParam.sort = sort
    }
    loadGoodsList()
}

// 修改商品上下架状态
let statusRepeat = false
const statusChange = (row: any, value: any) => {
    if (value) {
        if (statusRepeat) return
        statusRepeat = true
        editGoodsStatus({
            goods_ids: row.goods_id,
            status: value
        }).then((res) => {
            statusRepeat = false
            getGoodsStatusFn()
            loadGoodsList()
        }).catch(() => {
            statusRepeat = false
        })
    } else {
        ElMessageBox.confirm(t('statusChangeTips'), t('warning'),
            {
                confirmButtonText: t('confirm'),
                cancelButtonText: t('cancel'),
                type: 'warning'
            }
        ).then(() => {
            editGoodsStatus({
                goods_ids: row.goods_id,
                status: value
            }).then((res) => {
                loadGoodsList()
            })
        })
    }
}

// 批量设置上下架
const batchGoodsStatus = (status: any) => {
    const isNoneSelected =
        (!isSelectAllPages.value && multipleSelection.value.length === 0) ||
        (isSelectAllPages.value && excludedIds.value.length === goodsTable.total)

    if (isNoneSelected) {
        ElMessage({
            type: 'warning',
            message: `${t('batchEmptySelectedGoodsTips')}`
        })
        return
    }
    const info = getBatchPayload()
    editGoodsStatus({
        is_all: info.is_all,
        goods_ids: info.ids,
        where: info.where,
        status
    }).then((res) => {
        isReset.value = true
        loadGoodsList()
    })
}

/** ***************** 批量设置-start *************************/
const goodsBatchSettingPopupRef = ref()
const batchSetGoods = () => {
    const isNoneSelected =
    (!isSelectAllPages.value && multipleSelection.value.length === 0) ||
    (isSelectAllPages.value && excludedIds.value.length === goodsTable.total)

    if (isNoneSelected) {
        ElMessage({
            type: 'warning',
            message: `${t('batchEmptySelectedGoodsTips')}`
        })
        return
    }
    const info = getBatchPayload()
    goodsBatchSettingPopupRef.value.show(info)
}

/** ***************** 批量设置-end *************************/

const batchDeleteGoods = () => {
    const isNoneSelected =
    (!isSelectAllPages.value && multipleSelection.value.length === 0) ||
    (isSelectAllPages.value && excludedIds.value.length === goodsTable.total)

    if (isNoneSelected) {
        ElMessage({
            type: 'warning',
            message: `${t('batchEmptySelectedGoodsTips')}`
        })
        return
    }
    ElMessageBox.confirm(t('batchGoodsDeleteTips'), t('warning'),
        {
            confirmButtonText: t('confirm'),
            cancelButtonText: t('cancel'),
            type: 'warning'
        }
    ).then(() => {
        if (repeat.value) return
        repeat.value = true
        const info = getBatchPayload()
        deleteGoods({
            is_all: info.is_all,
            goods_ids: info.ids,
            where: info.where
        }).then(() => {
            isReset.value = true
            loadGoodsList()
            repeat.value = false
        }).catch(() => {
            repeat.value = false
        })
    })
}

// 修改排序号
const sortInputListener = debounce((shopSort, row) => {
    if (isNaN(shopSort) || !regExp.number.test(shopSort)) {
        ElMessage({
            type: 'warning',
            message: `${t('sortTips')}`
        })
        return
    }
    editGoodsSort({
        goods_id: row.goods_id,
        shop_sort: shopSort
    }).then((res) => {
        // loadGoodsList();
    })
})

const isReset = ref(false)
/**
 * 获取商品列表
 */
const loadGoodsList = (page: number = 1) => {
    if (goodsTable.searchParam.start_sale_num && !regExp.digit.test(goodsTable.searchParam.start_sale_num)) {
        ElMessage({
            type: 'warning',
            message: `${t('startSaleNumTips')}`
        })
        return
    }
    if (goodsTable.searchParam.end_sale_num && !regExp.digit.test(goodsTable.searchParam.end_sale_num)) {
        ElMessage({
            type: 'warning',
            message: `${t('endSaleNumTips')}`
        })
        return
    }
    if (Number(goodsTable.searchParam.start_sale_num) > Number(goodsTable.searchParam.end_sale_num)) {
        ElMessage({
            type: 'warning',
            message: `${t('shopSaleNumTips')}`
        })
        return
    }
    if (goodsTable.searchParam.start_price && !regExp.digit.test(goodsTable.searchParam.start_price)) {
        ElMessage({
            type: 'warning',
            message: `${t('startPriceTips')}`
        })
        return
    }
    if (goodsTable.searchParam.end_price && !regExp.digit.test(goodsTable.searchParam.end_price)) {
        ElMessage({
            type: 'warning',
            message: `${t('endPriceTips')}`
        })
        return
    }
    if (Number(goodsTable.searchParam.start_price) > Number(goodsTable.searchParam.end_price)) {
        ElMessage({
            type: 'warning',
            message: `${t('shopPriceTips')}`
        })
        return
    }
    goodsTable.loading = true
    goodsTable.page = page

    const searchData = cloneDeep(goodsTable.searchParam)

    getGoodsPageList({
        page: goodsTable.page,
        limit: goodsTable.limit,
        ...searchData
    }).then(res => {
        goodsTable.loading = false
        goodsTable.data = res.data.data
        goodsTable.total = res.data.total
        setTablePageStorage(goodsTable.page, goodsTable.limit, searchData)
        if (isReset.value) {
            isSelectAllPages.value = false
            excludedIds.value = []
            currentSelectMode.value = null
            multipleSelection.value = []
        }
        if (isSelectAllPages.value && !isReset.value) {
            restoringSelection.value = true
            nextTick(() => {
                goodsTable.data.forEach(item => {
                    if (!excludedIds.value.includes(item.goods_id)) {
                        goodsListTableRef.value?.toggleRowSelection(item, true)
                    } else {
                        goodsListTableRef.value?.toggleRowSelection(item, false)
                    }
                })

                restoringSelection.value = false
            })
        }
        isReset.value = false
        getGoodsStatusFn()
    }).catch(() => {
        isReset.value = false
        goodsTable.loading = false
    })
}

loadGoodsList(getTablePageStorage(goodsTable.searchParam).page)

/**
 * 添加商品
 */
const addEvent = () => {
    router.push('/mall/goods/real_edit')
    // let url = router.resolve({
    //     path: '/mall/goods/real_edit',
    // });
    // window.open(url.href);
}

/**
 * 编辑商品
 * @param data
 */
const editEvent = (data: any) => {
    router.push(data.goods_edit_path + '?goods_id=' + data.goods_id)
    // let url = router.resolve({
    //     path: data.goods_edit_path,
    //     query: {goods_id: data.goods_id}
    // });
    // window.open(url.href);
}

const goodsPriceEditPopupRef: any = ref(null)

// 编辑商品价格
const editPriceEvent = (data: any) => {
    if (data.supply_id) return
    goodsPriceEditPopupRef.value.show(data)
}

const goodsStockEditPopupRef: any = ref(null)

// 编辑商品库存
const editStockEvent = (data: any) => {
    goodsStockEditPopupRef.value.show(data)
}

// 商品推广
const spreadPopupRef = ref(null)

const spreadEvent = (data: any) => {
    const pagePath = '/addon/mall/pages/goods/detail'
    const paramsArr = [
        { name: 'goods_id', value: data.goods_id },
    ];
    const title = '商品推广'
    const folder = 'goods'
    spreadPopupRef.value?.show(pagePath, paramsArr, title, folder);
}

/** ***************** 会员价-start *************************/
// 会员等级
const memberLevel = ref([])
const getMemberLevelAllFn = () => {
    getMemberLevelAll().then(res => {
        memberLevel.value = res.data ? res.data : []
    })
}
getMemberLevelAllFn()

const memberPricePopupRef: any = ref(null)
const memberPriceEvent = (data: any) => {
    memberPricePopupRef.value.show(data, memberLevel.value)
}
/** ***************** 会员价-end *************************/

/** ***************** 付费会员价-start *************************/
const vipcardLevel = ref([])
const getVipcardAllFn = () => {
    getVipcardAll().then(res => {
        vipcardLevel.value = res.data ? res.data : []
    })
}

getVipcardAllFn()

const vipcardPricePopupRef: any = ref(null)
const vipcardPriceEvent = (data: any) => {
    vipcardPricePopupRef.value.show(data, vipcardLevel.value)
}

/** ***************** 付费会员价-end *************************/

// 复制商品
const copyEvent = (data: any) => {
    ElMessageBox.confirm(t('goodsCopyTips'), t('warning'),
        {
            confirmButtonText: t('confirm'),
            cancelButtonText: t('cancel'),
            type: 'warning'
        }
    ).then(() => {
        if (repeat.value) return
        repeat.value = true

        copyGoods({
            goods_id: data.goods_id
        }).then((res: any) => {
            if (res.code == 1) {
                loadGoodsList()
            }
            repeat.value = false
        }).catch(() => {
            repeat.value = false
        })
    })
}

// 删除商品
const deleteEvent = (id: number) => {
    ElMessageBox.confirm(t('goodsDeleteTips'), t('warning'),
        {
            confirmButtonText: t('confirm'),
            cancelButtonText: t('cancel'),
            type: 'warning'
        }
    ).then(() => {
        if (repeat.value) return
        repeat.value = true
        deleteGoods({
            goods_ids: id
        }).then(() => {
            loadGoodsList()
            repeat.value = false
        }).catch(() => {
            repeat.value = false
        })
    })
}

// 批量重置全选状态
const loadGoodsListReset = () => {
    isReset.value = true
    goodsBatchSettingPopupRef.value.showDialog = false
    loadGoodsList()
}

const resetForm = (formEl: FormInstance | undefined) => {
    if (!formEl) return
    formEl.resetFields()
    goodsTable.searchParam.start_price = ''
    goodsTable.searchParam.end_price = ''
    goodsTable.searchParam.start_sale_num = ''
    goodsTable.searchParam.end_sale_num = ''
    isReset.value = true
    loadGoodsList()
}

// 审核未通过弹框
const auditRefuseDialog = ref(false)
const refuseData = ref('')
const handleAuditRefuse = (data:any) => {
    refuseData.value = data
    auditRefuseDialog.value = true
}

// 供货详情
const supplyDetailPopupRef: any = ref(null)
const supplyEvent = (data: any) => {
    supplyDetailPopupRef.value.show(data)
}

/**
 * 商品导出
 */
const exportSureDialog = ref(null)
const flag = ref(false)
const handleClose = (val) => {
    flag.value = val
}
const exportEvent = (data: any) => {
    flag.value = true
}
</script>

<style lang="scss" scoped>
/* 多行超出隐藏 */
.multi-hidden {
    word-break: break-all;
    text-overflow: ellipsis;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}

.input-width-sort {
    width: 70px;
}

.price-wrap {
    &:hover {
        .icon-wrap {
            visibility: visible;
        }
    }
}

.stock-wrap {
    &:hover {
        .icon-wrap {
            visibility: visible;
        }
    }
}
:deep(.sort-column .cell){
    display:flex;
    align-items: center;
}
</style>
