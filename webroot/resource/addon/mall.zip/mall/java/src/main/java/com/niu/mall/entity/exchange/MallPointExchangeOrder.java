package com.niu.mall.entity.exchange;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 积分兑换订单实体
 */
@Data
public class MallPointExchangeOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value="order_id", type= IdType.AUTO)
    private Integer orderId; // 兑换记录id
    private String orderNo; // 订单编号
    private String outTradeNo; // 支付流水表
    private Integer siteId; // 站点id
    private Integer exchangeId; // 兑换活动id
    private String exchangeName; // 兑换商品名称
    private String exchangeImage; // 兑换商品图片
    private String type; // 兑换类型
    private Integer memberId; // 消费会员id
    private Integer memberAddressId; // 会员地址id
    private Integer relateId; // 关联业务id
    private Integer relateOrderId; // 关联订单id
    private Integer point; // 使用积分
    private BigDecimal price; // 支付金额
    private BigDecimal balance; // 赠送余额
    private Long createTime; // 创建时间
    private Integer payTime; // 兑换时间
    private Integer closeTime; // 关闭时间
    private Long deleteTime; // 订单删除
    private Integer num; // 兑换数量
    private String status; // 订单状态
    private BigDecimal orderMoney; // 订单金额

}